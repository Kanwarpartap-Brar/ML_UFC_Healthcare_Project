#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd


#transform ufc fights summary dataset into fighter specific dataset
#need to have every single fighters average fight stats per round in each category (sig strikes, takedowns, etc)


#load the dataset
UFC_fight_statistic_data = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Fight_Data/UFC_Fight_Statistics.csv')
#UFC_fight_statistic_data.head()

#in this dataset each row is fight, the goal is to tranform this dataset to make each row a fighter
#this way we have all the data (avg stats) for each fighter in the UFC (that fought in the past 8 years)

#first we want to find all features that are dedicated toward Figheter 1 (F1) and Fighter 2 (F2)
#we can tell which is which because the features have F1 or F2 in their name 
#go through all column names and only keep the ones that contain 'F1'

F1_features = [col for col in UFC_fight_statistic_data.columns if 'F1' in col ] #all F1 features
F2_features = [col for col in UFC_fight_statistic_data.columns if 'F2' in col] #all F2 features

#print(F1_features)
#rint(F2_features)

#now we create a dataframe that has all of Fighter1 statistics 
#this creates examples on a per fight basis for every single fighter instead of fighter1 vs fighter2
#this df accounts for all fighters who were Fighter1 (favorites)

F1_performance = UFC_fight_statistic_data[['Fighter1', 'Winner?'] + F1_features].copy() #Contains Fighter1 name, Winner label, and the rest of important features

#renaming columns for simplicity
F1_performance.columns = ['Fighter', 'Winner'] + [col.replace(' F1', '') for col in F1_features]

#print(F1_performance.head()) 

#do the same thing for fighter2
#purpose of this is so we can combine both fighter1 and 2 dataframes to have one large df with all fighter statistics

F2_performance = UFC_fight_statistic_data[['Fighter2', 'Winner?'] + F2_features].copy()

#invert the winner column b/c originallly winner column only accounts for if F1 won
#without inverting a 1 would indicate F1 won NOT F2 

F2_performance['Winner?'] = 1-F1_performance['Winner']
#rename columns for simplicity 
F2_performance.columns = ['Fighter', 'Winner'] + [col.replace(' F2', '') for col in F2_features]

#print(F2_performance.head())

#combine both F1 performance and F2 performance dataframes
#this creates one large dataframe of all fighters and their performance in every single fight they fought and if they won or lost

fighter_performance_combined = pd.concat([F1_performance,F2_performance], ignore_index=True)
#print(fighter_performance_combined.head()) 

#fill all missing values with 0
#most fights are 3 rounds, so rounds 4 and 5 have a lot of missing values 
#it is better to fill these values with 0 (as they didnt happen) instead of removing the examples entierly 

fighter_performance_combined = fighter_performance_combined.fillna(0)
#print(fighter_performance_combined.head()) 

#lastly we calculate the avg performacne of each feature for each fight every fighter fought
#only averge the numeric columns that contain all the statistics (not Fighter & Winner)

all_stat_features = [col for col in fighter_performance_combined.columns if col not in ['Fighter','Winner']]
#get mean of all the fighter statistic features for every single fight that the fighter was in
complete_fighter_statistics = fighter_performance_combined.groupby('Fighter')[all_stat_features].mean()

#print(complete_fighter_statistics.head())

#save as csv
#complete_fighter_statistics.to_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/complete_fighter_statistics.csv')





































