import pandas as pd
from sklearn.model_selection import train_test_split



df = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/Code/cleaned_healthcare_data.csv')

train_df, test_df = train_test_split(df, test_size = 0.2, random_state = 42, stratify = df['Test Results'])

train_df.to_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/Code/cleaned_healthcare_train.csv')

test_df.to_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/Code/cleaned_healthcare_test.csv')

