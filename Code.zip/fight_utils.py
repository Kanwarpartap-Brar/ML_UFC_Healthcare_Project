#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import pandas as pd

#this is to create a function that allows a conversion of the fight stat features
#inputs a fight (from UFC dataset) and inputs stats of a fighter (complete fighter statistics dataset)

#output is the a feature difference matrix with the label 'Winner'

def convert_to_feature_vector(UFC_data, fighter_data):
    X = [] #feature vectors holds all the features
    y = []  #labels hold all corresponding labels (who won)
    
    #loop through each fight example in UFC dataset 
    
    for i in range(len(UFC_data)):
        example = UFC_data.iloc[i] #ith example
        #get names of both fighter in that example (fight)
        fighter_1 = example['Fighter1']
        fighter_2 = example['Fighter2']
        label = example['Winner?']
        #check to see if both fighters are in the avg stats dataset
        #this checks to see if there is not a fighter that is making their debut in the UFC
        
        if fighter_1 in fighter_data.index and fighter_2 in fighter_data.index:
            
            #both fighters have avg stats from previous fights then continue
            fighter_1_stats = fighter_data.loc[fighter_1] #get stats for fighter 1
            fighter_2_stats= fighter_data.loc[fighter_2] #get stats for fighter 2
            
            #get the diff of the two to get a feature vector of differences
            feature_vector_differences = fighter_1_stats - fighter_2_stats 
            #append feature vector to feature_vector
            X.append(feature_vector_differences.values)
            #also append the result of that fight
            y.append(label)
        #return as a df and series with column names from stats dataset
    return pd.DataFrame(X, columns = fighter_data.columns), pd.Series(y)
    
    
#predicting fight winner function

def predict_winner(fighter1, fighter2, fighter_stat_data, model_name ):
    #check to see if fighters are in the dataset
    if fighter1 not in fighter_stat_data.index:
        return fighter1 + ': Not Found'
    if fighter2 not in fighter_stat_data.index:
        return fighter2 + ': Not Found'
    
    #get the data of each fighter
    fighter_1_stats = fighter_stat_data.loc[fighter1] #get stats for fighter 1
    fighter_2_stats= fighter_stat_data.loc[fighter2] #get stats for fighter 2
    
    #difference
    feature_vector_differences = pd.DataFrame([fighter_1_stats - fighter_2_stats]) 
    
    #make predictions
    predict = model_name.predict(feature_vector_differences)[0]
    #calculate probability of which fighter wins based on how many features fighter 1vsfighter 2 won on
    win_probability = model_name.predict_proba(feature_vector_differences)[0]
    
    #who won
    winner = fighter1 if predict == 1 else fighter2 
    probability = round(win_probability[predict],4) #get probability
    
    return 'Predicted Winner: ' + winner + ' | Probability: ' + str(probability)
    


























