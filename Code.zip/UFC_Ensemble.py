#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from fight_utils import convert_to_feature_vector
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV
import matplotlib.pyplot as plt
from fight_utils import predict_winner
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.preprocessing import StandardScaler
import seaborn as sns

def ensemble():
    

    #load training dataset from Phase1
    #load fighter statistic dataset with the fighter name as the index
    training_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Train_Data.csv')
    testing_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Test_Data.csv')
    fighter_stats_data = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/complete_fighter_statistics.csv', index_col = 'Fighter')

    #convert fights into the feature vector using the conver_to_feature_vector dataset

    X_train_original, y_train_original = convert_to_feature_vector(training_dataset, fighter_stats_data)
    X_test, y_test = convert_to_feature_vector(testing_dataset, fighter_stats_data) 


    #split training data into training and validation for more optimal hyperparameter tuning
    X_train, X_val, y_train, y_val = train_test_split(X_train_original, y_train_original, test_size = 0.2, random_state = 42)

    #hyperparameter tuning using GridSearchCV
    #tuning for max_depth and n_estimators 

    UFC_ensemble = RandomForestClassifier(random_state = 42)

    #tuning parameters 

    tuning_parameters = { 'max_depth': [1,10,20,30], 'n_estimators': [10,50,100,150,200]}


    grid_search = GridSearchCV(UFC_ensemble, tuning_parameters, cv = 5, scoring = 'accuracy', verbose = 3)
    grid_search.fit(X_train, y_train)

    #get best model with the optimal tuned hyperparameters
    optimal_ensemble_model = grid_search.best_estimator_

    print('\n')
    print('Optimal Random Forest Classifier Hyperparameters: ')
    print(grid_search.best_params_)


    #now train model on the full training set using optimal hyperparameters

    optimal_UFC_ensemble = RandomForestClassifier(max_depth = grid_search.best_params_['max_depth'], n_estimators = grid_search.best_params_['n_estimators'], random_state = 42)

    #fit on full training data
    optimal_UFC_ensemble.fit(X_train_original, y_train_original)
    y_prediction = optimal_UFC_ensemble.predict(X_test)


    #hyperparameter tuning plot

    cross_validation_results = pd.DataFrame(grid_search.cv_results_)

    #get all depths that were tested
    colors = ['red', 'blue', 'yellow', 'purple', 'green']

    all_depths = sorted(cross_validation_results['param_max_depth'].unique())

    for idx, i in enumerate(all_depths):
        #start where the depth = max_depth
        current = cross_validation_results[cross_validation_results['param_max_depth'] == i]
        plt.plot( current['param_n_estimators'], current['mean_test_score'], marker = 'x', color = colors[idx], label = 'max_depth = ' + str(i))
    
    plt.title("Max_Depth & n_estimators Tuning")
    plt.xlabel('n_estimators')
    plt.ylabel('Accuracy Score')
    plt.legend(title = 'Max_Depth')
    plt.grid(True)
    plt.show()

    #model evaluation

    #accuracy score

    accuracy = accuracy_score(y_test, y_prediction) 

    print('\n')
    print('Optimal Test Accuracy: ', round(accuracy,4))


    #model evaluation: accuracy, f1, recall, and precision using classification report

    print('\n')
    print('Classification Report: ')
    print(classification_report(y_test, y_prediction, target_names = ['Fighter2 Wins', 'Fighter1 Wins'] ))


    #confusion matrix

    plt.figure()
    confusion_mat = confusion_matrix(y_test, y_prediction)
    disp = ConfusionMatrixDisplay(confusion_matrix = confusion_mat, display_labels =['Fighter2 Wins', 'Fighter1 Wins'] )
    disp.plot()
    plt.title('Random Forest Classifier Confusion Matrix')
    plt.show()
    


if __name__ == '__main__':
    ensemble()



















