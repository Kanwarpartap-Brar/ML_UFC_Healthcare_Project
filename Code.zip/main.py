from UFC_Decision_Tree import decision_tree
from UFC_Logistic_Regression import logistic_regression
from UFC_SVM import SVM
from UFC_Ensemble import ensemble
from healthcare_KNN import KNN
from healthcare_perceptron import perceptron
from healthcare_SVM import SVM_healthcare
from healthcare_ensemble import healthcare_random_forest


def main():
    print('\n')
    print("Decision Tree Model (UFC dataset)")
    decision_tree()
    
    print('\n')
    print('Logistic Regression Model (UFC dataset)')
    logistic_regression()
    
    print('\n')
    print('SVM Model')
    SVM()
    
    print('\n')
    print('Random Forest Classifier Model (UFC dataset)')
    ensemble()
    
    print('\n')
    print('KNN Model (healthcare dataset)')
    KNN()
    
    print('\n')
    print('Perceptron Model (healthcare dataset)')
    perceptron()
    
    print('\n')
    print('SVM Model (healthcare dataset)')
    SVM_healthcare()
    
    print('\n')
    print('Random Forest Classifier Model (healthcare dataset)')
    healthcare_random_forest()
    
if __name__ == '__main__':
    main()




















