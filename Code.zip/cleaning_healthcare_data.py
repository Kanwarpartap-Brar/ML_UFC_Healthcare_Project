import pandas as pd

#cleaning/pre-processing the healthcare dataset to improve the model performance

#load dataset
healthcare_data = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/submissions/dataset_multiclass/healthcare_dataset.csv')

#drop irrelevant columns
#Doctor, Hospital, Room Number, Insurance Provider 

healthcare_data.drop(columns = ['Doctor', 'Hospital', 'Room Number', 'Insurance Provider'], inplace = True)

#convert date to datetime formats

healthcare_data['Date of Admission'] = pd.to_datetime(healthcare_data['Date of Admission'])
healthcare_data['Discharge Date'] = pd.to_datetime(healthcare_data['Discharge Date'])

#subtract date of admission from discharge date to calculate how long a patient stayed in the hospital
#knowing the duration of stay may be more useful because it can be a better indicator to understand how serious their condition may be

healthcare_data['Duration'] = (healthcare_data['Discharge Date'] - healthcare_data['Date of Admission']).dt.days #.dt.days for number of days

#get rid of previous date columns, dont need them anymore

healthcare_data.drop(columns = ['Date of Admission', 'Discharge Date'], inplace = True)

#use one-hot encoding to preprocess all the categorical features

#categorical features
categorical_features = ['Gender', 'Blood Type', 'Medical Condition', 'Admission Type', 'Medication']
healthcare_data = pd.get_dummies(healthcare_data, columns = categorical_features)

#save
#healthcare_data.to_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/Code/cleaned_healthcare_data.csv')












