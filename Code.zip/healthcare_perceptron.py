import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))

import pandas as pd
from sklearn.linear_model import Perceptron
from sklearn.multiclass import OneVsRestClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV
import matplotlib.pyplot as plt
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import LabelEncoder

def perceptron():
    
    #load training and testing datasets
    train_healthcare_dataset = pd.read_csv('cleaned_healthcare_train.csv')
    test_healthcare_dataset = pd.read_csv('cleaned_healthcare_test.csv')
    #train_healthcare_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/Code/cleaned_healthcare_train.csv')
    #test_healthcare_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/Code/cleaned_healthcare_test.csv')
    
    #drop unnecesary columns in the data that were created and split labels and features
    drop_cols = ['Unnamed: 0', 'Unnamed: 0.1']
    train_healthcare_dataset.drop(columns=[col for col in drop_cols if col in train_healthcare_dataset.columns], inplace=True)
    test_healthcare_dataset.drop(columns=[col for col in drop_cols if col in test_healthcare_dataset.columns], inplace=True)
    
    
    X_train = train_healthcare_dataset.drop(columns=['Name', 'Test Results'])
    y_train = train_healthcare_dataset['Test Results']

    X_test = test_healthcare_dataset.drop(columns=['Name', 'Test Results'])
    y_test = test_healthcare_dataset['Test Results']
    
    #have to encode the labels using labelencoder because they are strings
    
    label_encoder = LabelEncoder()
    y_train = label_encoder.fit_transform(y_train)
    y_test = label_encoder.transform(y_test)
    
    #standardize features around mean for better calculation of distance between points for KNN
    
    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train)
    X_test_s = scaler.transform(X_test)
    
    #hyperparameter tuning using GridSearchCV
    #tuning for max iterations and alpha
    #dont have to manually split for training and validation, gridsearch will do that
    #set up model for gridsearch
    
    #use onevsrest with the perceptron model
    original_percep_model = Perceptron(random_state = 42)
    one_vs_rest_model = OneVsRestClassifier(original_percep_model)
    
    max_iterations = [100,200,300,400,500]
    #perceptron uses eta0 as alpha notation
    alpha = [ .001, .01, .1 ]
    
    tuning_parameters = {'estimator__max_iter': max_iterations, 'estimator__eta0':alpha}
    
    #implement gridsearch using 5-fold cross validation 
    #measure performance based on accuracy score
    
    grid_search = GridSearchCV(one_vs_rest_model, tuning_parameters, cv = 5, scoring = 'accuracy', verbose = 3)
    grid_search.fit(X_train_s, y_train)
    
    #get best model with the optimal tuned hyperparameters
    
    optimal_model = grid_search.best_estimator_
    
    y_prediction = optimal_model.predict(X_test_s)
    
    print('\n')
    print('Optimal Perceptron Hyperparameters: ')
    print(grid_search.best_params_)
    
    #hyperparameter tuning plot
    
    cross_validation_results = pd.DataFrame(grid_search.cv_results_)
    
    alpha_vals = sorted(cross_validation_results['param_estimator__eta0'].unique())
    
    for i in alpha_vals:
        current = cross_validation_results[cross_validation_results['param_estimator__eta0'] == i]
        plt.plot(current['param_estimator__max_iter'], current['mean_test_score'], marker = 'x', label = 'eta0 = ' + str(i) )
    
    plt.title("max_iters & alpha Tuning")
    plt.xlabel('max_iter')
    plt.ylabel('Accuracy Score')
    plt.legend(title = 'alpha')
    plt.grid(True)
    plt.show()  
    
    
    #model evaluation
    #accuracy score

    accuracy = accuracy_score(y_test, y_prediction) 

    print('\n')
    print('Optimal Test Accuracy: ', round(accuracy,4))


    #model evaluation: accuracy, f1, recall, and precision using classification report

    print('\n')
    print('Classification Report: ')
    print(classification_report(y_test, y_prediction, target_names = label_encoder.classes_ ))


    #confusion matrix

    plt.figure()
    confusion_mat = confusion_matrix(y_test, y_prediction)
    disp = ConfusionMatrixDisplay(confusion_matrix = confusion_mat, display_labels = label_encoder.classes_ )
    disp.plot()
    plt.title('Perceptron Confusion Matrix')
    plt.show()


if __name__ == '__main__':
    perceptron()









