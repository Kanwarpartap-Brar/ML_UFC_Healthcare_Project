#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

import pandas as pd
from sklearn.svm import SVC
from fight_utils import convert_to_feature_vector
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV
import matplotlib.pyplot as plt
from fight_utils import predict_winner
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.preprocessing import StandardScaler
import seaborn as sns

def SVM():
    

    #load training dataset from Phase1
    #load fighter statistic dataset with the fighter name as the index
    training_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Train_Data.csv')
    testing_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Test_Data.csv')
    fighter_stats_data = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/complete_fighter_statistics.csv', index_col = 'Fighter')

    #convert fights into the feature vector using the conver_to_feature_vector dataset

    X_train_original, y_train_original = convert_to_feature_vector(training_dataset, fighter_stats_data)
    X_test, y_test = convert_to_feature_vector(testing_dataset, fighter_stats_data) 


    #standardize features around mean for better convergence on logistic regression
    scaler = StandardScaler()
    X_train_original = scaler.fit_transform(X_train_original)
    X_test = scaler.transform(X_test)


    #split training data into training and validation for more optimal hyperparameter tuning
    X_train, X_val, y_train, y_val = train_test_split(X_train_original, y_train_original, test_size = 0.2, random_state = 42)


    #hyperparameter tuning using GridSearchCV
    #tuning for C and kernel

    #set up model for gridsearch
    UFC_SVM = SVC(random_state = 42)

    #values of potential hyperparameters

    C_Vals = [.01, .1, 1, 10] #cant use higher C values bc it takes way too long to compute
    Kernel_Vals = ['linear', 'poly', 'rbf'] 

    #tuning parameters 

    tuning_parameters = { 'C': C_Vals, 'kernel': Kernel_Vals}

    #implement gridsearch using 5-fold cross validation 
    #measure performance based on accuracy score


    grid_search = GridSearchCV(UFC_SVM, tuning_parameters, cv = 5, scoring = 'accuracy', verbose = 3)
    grid_search.fit(X_train, y_train)

    #get best model with the optimal tuned hyperparameters
    optimal_SVM_model = grid_search.best_estimator_

    print('\n')
    print('Optimal SVM Hyperparameters: ')
    print(grid_search.best_params_)


    #now train model on the full training set using optimal hyperparameters

    optimal_UFC_SVM = SVC(C = grid_search.best_params_['C'], kernel = grid_search.best_params_['kernel'], random_state = 42)

    #fit on full training data
    optimal_UFC_SVM.fit(X_train_original, y_train_original)
    y_prediction = optimal_UFC_SVM.predict(X_test)


    #hyperparameter tuning plot 


    cross_validation_results = pd.DataFrame(grid_search.cv_results_)

    #kerenl x C matrix to display what kerenel was used with what value of C

    matrix = cross_validation_results.pivot_table(values = 'mean_test_score', index = 'param_kernel', columns = 'param_C')
    sns.heatmap(matrix, annot = True, fmt = '.4f', cmap = 'viridis')


    plt.title("SVM Kernel Vs C (Accuracy)")
    plt.xlabel('C')
    plt.ylabel('Kernel')
    plt.show()



    #MODEL EVALUATION

    #accuracy score

    accuracy = accuracy_score(y_test, y_prediction) 

    print('\n')
    print('Optimal Test Accuracy: ', round(accuracy,4))
    

    #model evaluation: accuracy, f1, recall, and precision using classification report
    
    print('\n')
    print('Classification Report: ')
    print(classification_report(y_test, y_prediction, target_names = ['Fighter2 Wins', 'Fighter1 Wins'] ))


    #confusion matrix

    plt.figure()
    confusion_mat = confusion_matrix(y_test, y_prediction)
    disp = ConfusionMatrixDisplay(confusion_matrix = confusion_mat, display_labels =['Fighter2 Wins', 'Fighter1 Wins'] )
    disp.plot()
    plt.title('SVM Confusion Matrix')
    plt.show()


if __name__ == '__main__':
    SVM()


















