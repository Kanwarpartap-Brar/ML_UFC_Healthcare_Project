#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from fight_utils import convert_to_feature_vector
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from fight_utils import predict_winner
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay


def decision_tree():
    

    #load training dataset from Phase1
    #load fighter statistic dataset with the fighter name as the index
    training_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Train_Data.csv')
    testing_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Test_Data.csv')
    fighter_stats_data = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/complete_fighter_statistics.csv', index_col = 'Fighter')

    #convert fights into the feature vector using the conver_to_feature_vector dataset

    X_train_original, y_train_original = convert_to_feature_vector(training_dataset, fighter_stats_data)
    X_test, y_test = convert_to_feature_vector(testing_dataset, fighter_stats_data) 


    #split training data into training and validation for more optimal hyperparameter tuning
    X_train, X_val, y_train, y_val = train_test_split(X_train_original, y_train_original, test_size = 0.2, random_state = 42)




    #Hyperparameter Tuning (training and validation sets)
    #Tuning to find optimal 'max_depth' and optimal criterion ('Entropy' Or 'Gini')

    #hyperparameter tested
    max_depth_hyperparameter = 20
    criterion = ['gini', 'entropy'] #either gini or entropy

    #initialize variables
    best_accuracy = 0 
    optimal_depth = None
    optimal_criterion = None

    results = {} #stores training and val accuracy scores for both criterions

    #similar loop to assignment 1

    for c in criterion:
        i = 1 #initialize at 1
        training_accuracy_score = [] #holds training accuracies
        validation_accuracy_score = [] #holds validation accuracies
        depth = [] #current depth
    
        while i <= max_depth_hyperparameter:
            DT_model = DecisionTreeClassifier(max_depth = i, criterion = c, random_state = 42)
        
            #train model on training data
            DT_model.fit(X_train, y_train)
            #evaluate on both training and val datasets
        
            training_accuracy = accuracy_score(y_train, DT_model.predict(X_train))
            validation_accuracy = accuracy_score(y_val, DT_model.predict(X_val))
        
            #append accuracy scores and depths into list
            training_accuracy_score.append(training_accuracy)
            validation_accuracy_score.append(validation_accuracy)
            depth.append(i)
        
            #if this model is the best, then update
            if validation_accuracy > best_accuracy:
                best_accuracy = validation_accuracy
                optimal_depth = i
                optimal_criterion = c
            i += 1
                
            #save scores for the criterions
            results[c] = {'Training': training_accuracy_score, 'Validation': validation_accuracy_score}    
 
    #results

    print('Best Model')
    print('Optimal Max_Depth: ', optimal_depth)
    print('Optimal Criterion: ', optimal_criterion)


    #plot hyperparameter tuning graphs

    #loop through both criterions
    for c in criterion:
        depths = list(range(1, max_depth_hyperparameter + 1)) #(1-20)
    
        #plot training accuracy
        plt.plot(depths, results[c]['Training'], label = c + '-Training', color = 'blue' if c == 'gini' else 'red', marker='x')
        plt.plot(depths, results[c]['Validation'], label = c + '-Validation', color = 'green' if c == 'gini' else 'yellow', marker ='o')
    
    plt.xlabel('Max Depth')
    plt.ylabel('Accuracy')
    plt.title('Hyperparameter Tuning For Optimal Depth')
    plt.legend()
    plt.grid(True)
    #plt.xticks(ticks = depth)


    #train decision tree model on optimal hyperparameters

    UFC_Decision_Tree_Model = DecisionTreeClassifier(max_depth = 4, criterion = 'gini', random_state = 42)
    UFC_Decision_Tree_Model.fit(X_train_original, y_train_original)

    #prediction
    y_prediction = UFC_Decision_Tree_Model.predict(X_test)

    #Model Evaluation

    accuracy = accuracy_score(y_test, y_prediction) 

    print('\n')
    print('Optimal Test Accuracy: ', round(accuracy,4))

    #check to see if dataset is balanced
    print('\n')
    print('Test Set Distribution: ') 
    print(y_test.value_counts())

    #model evaluation: accuracy, f1, recall, and precision using classification report

    print('\n')
    print('Classification Report: ')
    print(classification_report(y_test, y_prediction, target_names = ['Fighter2 Wins', 'Fighter1 Wins'] ))

    #confusion matrix

    plt.figure()
    confusion_mat = confusion_matrix(y_test, y_prediction)
    disp = ConfusionMatrixDisplay(confusion_matrix = confusion_mat, display_labels =['Fighter2 Wins', 'Fighter1 Wins'] )
    disp.plot()
    plt.title('Decision Tree Confusion Matrix')


    plt.show()



if __name__ == '__main__':
    decision_tree()
