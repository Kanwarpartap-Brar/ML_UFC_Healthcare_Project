#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(script_dir)

import pandas as pd
from sklearn.linear_model import LogisticRegression
from fight_utils import convert_to_feature_vector
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split, GridSearchCV
import matplotlib.pyplot as plt
from fight_utils import predict_winner
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
from sklearn.preprocessing import StandardScaler

def logistic_regression():
    

    #load training dataset from Phase1
    #load fighter statistic dataset with the fighter name as the index
    training_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Train_Data.csv')
    testing_dataset = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_1/UFC_Test_Data.csv')
    fighter_stats_data = pd.read_csv('/Users/shawnbrar/Desktop/Hofstra_Classes/Machine_Learning/Course_Project/Phase_3/complete_fighter_statistics.csv', index_col = 'Fighter')

    #convert fights into the feature vector using the conver_to_feature_vector dataset

    X_train_original, y_train_original = convert_to_feature_vector(training_dataset, fighter_stats_data)
    X_test, y_test = convert_to_feature_vector(testing_dataset, fighter_stats_data) 

    #standardize features around mean for better convergence on logistic regression
    scaler = StandardScaler()
    X_train_original = scaler.fit_transform(X_train_original)
    X_test = scaler.transform(X_test)


    #split training data into training and validation for more optimal hyperparameter tuning
    X_train, X_val, y_train, y_val = train_test_split(X_train_original, y_train_original, test_size = 0.2, random_state = 42)


    #hyperparameter tuning using GridSearchCV
    #tuning for max_iters & alpha

    #set up model for gridsearch
    #l2 loss becasue we dont want to remove any features, all features are useful
    UFC_Logistic_Regression = LogisticRegression(penalty = 'l2', solver = 'lbfgs', random_state = 42)

    #values of potential alphas

    alpha_values = [.01, 1, 10, 100, 1000]

    #tuning parameters 
    #have to use C bc logistic regression inputs a value of C
    #so to train for alpha I have matched the alpha values to C

    tuning_parameters = { 'C': [1/alpha for alpha in alpha_values], 'max_iter': [50,100,150,200,250,300,350,400,450,500]}

    #implement gridsearch using 5-fold cross validation 
    #measure performance based on accuracy score

    grid_search = GridSearchCV(UFC_Logistic_Regression, tuning_parameters, cv = 5, scoring = 'accuracy', verbose = 1)
    grid_search.fit(X_train, y_train)
    #get best model with the optimal tuned hyperparameters
    optimal_logistic_regression_model = grid_search.best_estimator_

    print('\n')
    print('Optimal Logistic Regression Hyperparameters: ')
    print(grid_search.best_params_)
    #optimal C = .01, so optimal alpha = 100

    #now train model on the full training set using optimal hyperparameters

    optimal_UFC_Logistic_Regression = LogisticRegression(max_iter = grid_search.best_params_['max_iter'], C = grid_search.best_params_['C'], penalty = 'l2', solver = 'lbfgs', random_state = 42)

    #fit on full training data
    optimal_UFC_Logistic_Regression.fit(X_train_original, y_train_original)
    y_prediction = optimal_UFC_Logistic_Regression.predict(X_test)


    #hyperparameter tuning plots

    cross_validation_results = pd.DataFrame(grid_search.cv_results_)
    #add new 'alpha' column by taking inverse of C
    cross_validation_results['alpha'] = 1/cross_validation_results['param_C']

    #loop through and plot values for iterations on each alpha in order

    plot_folder = os.path.join(os.path.dirname(__file__), "Plots")
    os.makedirs(plot_folder, exist_ok=True)

    for alpha in sorted(cross_validation_results['alpha'].unique()):
        plt.plot(cross_validation_results.loc[cross_validation_results['alpha'] == alpha, 'param_max_iter'], 
                 cross_validation_results.loc[cross_validation_results['alpha'] == alpha, 'mean_test_score'], label = f'Alpha = {alpha}', marker = 'x')
    
    plt.xlabel('Max Iterations')
    plt.ylabel('Validation Accuracy')
    plt.title('Hyperparameter Tuning For Optimal Alpha & Max_Iters')
    plt.legend(loc = 'lower right')
    plt.grid(True)
    plt.show
    #plt.xticks(ticks = depth)


    #MODEL EVALUATION

    #accuracy score

    accuracy = accuracy_score(y_test, y_prediction) 

    print('\n')
    print('Optimal Test Accuracy: ', round(accuracy,4))


    #model evaluation: accuracy, f1, recall, and precision using classification report

    print('\n')
    print('Classification Report: ')
    print(classification_report(y_test, y_prediction, target_names = ['Fighter2 Wins', 'Fighter1 Wins'] ))

    #confusion matrix

    plt.figure()
    confusion_mat = confusion_matrix(y_test, y_prediction)
    disp = ConfusionMatrixDisplay(confusion_matrix = confusion_mat, display_labels =['Fighter2 Wins', 'Fighter1 Wins'] )
    disp.plot()
    plt.title('Logistic Regression Confusion Matrix')
    plt.show()


if __name__ == '__main__':
    logistic_regression()






























